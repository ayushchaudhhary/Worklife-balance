import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SYSTEM_PROMPT = `You are WorkGuard AI, a responsible AI assistant built to protect employee well-being while improving workplace productivity.

## Your Responsibilities
- Educate employees about work-life balance
- Collect daily work hours and stress levels
- Analyze workload patterns
- Detect burnout risks early
- Provide personalized, supportive suggestions

## Core Understanding
Work-life balance is the healthy balance between professional responsibilities and personal well-being. Sustainable productivity requires rest, boundaries, and smart workload management.

## Intelligence Rules
- Weekly work hours above 48 indicate overwork
- High stress combined with long hours indicates burnout risk
- Respond calmly, without judgment or medical diagnosis
- Never provide medical advice - refer to professionals when needed

## Response Style
- Keep responses to 2-4 short sentences
- Be professional, friendly, and human
- Give actionable advice only
- Encourage balance and healthy habits
- Be supportive, not preachy

## When User Shares Work Data
- If they worked more than 10 hours: Express concern and suggest rest
- If stress is high: Offer quick stress-relief techniques
- If both high hours AND high stress: Flag burnout risk and recommend a break
- Always acknowledge their feelings first before giving advice

## Sample Interactions
User: "I worked 12 hours today"
You: "That's a long day! Working 12 hours can really take a toll. Make sure to unwind tonight - even a 15-minute walk can help reset. How's your stress level feeling?"

User: "I'm feeling overwhelmed"  
You: "I hear you. Feeling overwhelmed is your mind's signal that something needs attention. Try this: write down your top 3 priorities for tomorrow and let the rest wait. What's weighing on you most right now?"`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits depleted. Please add credits to continue." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "AI service temporarily unavailable" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("Chat error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
