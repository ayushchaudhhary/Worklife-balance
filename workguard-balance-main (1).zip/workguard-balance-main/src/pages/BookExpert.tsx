import { useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Star, 
  Video, 
  CheckCircle2,
  CreditCard,
  Shield
} from "lucide-react";

const experts = [
  {
    id: "sarah-mitchell",
    name: "Dr. Sarah Mitchell",
    title: "Clinical Psychologist",
    specialty: "Workplace Stress",
    rating: 4.9,
    reviews: 127,
    availability: "Mon-Fri, 9AM-5PM",
    price: 75,
    image: "SM",
    bio: "Dr. Mitchell has over 15 years of experience helping professionals manage workplace stress and anxiety. She specializes in cognitive behavioral therapy and mindfulness-based stress reduction.",
    slots: ["9:00 AM", "10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM", "4:00 PM"]
  },
  {
    id: "michael-chen",
    name: "Michael Chen",
    title: "Executive Coach",
    specialty: "Work-Life Balance",
    rating: 4.8,
    reviews: 89,
    availability: "Tue-Sat, 10AM-6PM",
    price: 90,
    image: "MC",
    bio: "Michael is a certified executive coach who has helped hundreds of professionals achieve better work-life integration. His approach combines practical strategies with emotional intelligence coaching.",
    slots: ["10:00 AM", "11:00 AM", "1:00 PM", "3:00 PM", "5:00 PM"]
  },
  {
    id: "emily-rodriguez",
    name: "Dr. Emily Rodriguez",
    title: "Wellness Consultant",
    specialty: "Burnout Prevention",
    rating: 5.0,
    reviews: 156,
    availability: "Mon-Thu, 8AM-4PM",
    price: 85,
    image: "ER",
    bio: "Dr. Rodriguez is a leading expert in burnout prevention and recovery. She has developed proprietary methods used by Fortune 500 companies to help their employees thrive.",
    slots: ["8:00 AM", "9:00 AM", "10:00 AM", "1:00 PM", "2:00 PM", "3:00 PM"]
  }
];

const BookExpert = () => {
  const { expertId } = useParams();
  const navigate = useNavigate();
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isBooked, setIsBooked] = useState(false);

  const expert = experts.find(e => e.id === expertId);

  // Get next 7 days for date selection
  const getNextDays = () => {
    const days = [];
    for (let i = 1; i <= 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      days.push({
        date: date.toISOString().split('T')[0],
        display: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
      });
    }
    return days;
  };

  const handlePayment = async () => {
    if (!selectedSlot || !selectedDate) return;
    
    setIsProcessing(true);
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsProcessing(false);
    setIsBooked(true);
  };

  if (!expert) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-20">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">Expert not found</h1>
            <Link to="/#experts">
              <Button variant="hero">View All Experts</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (isBooked) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-20">
          <Card className="max-w-lg mx-auto border-0 shadow-elevated text-center">
            <CardContent className="p-8">
              <div className="w-20 h-20 rounded-full bg-stress-low/20 flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-stress-low" />
              </div>
              <h1 className="font-display text-2xl font-bold text-foreground mb-2">Booking Confirmed!</h1>
              <p className="text-muted-foreground mb-6">
                Your session with {expert.name} is scheduled for {selectedDate} at {selectedSlot}.
              </p>
              <div className="bg-muted rounded-xl p-4 mb-6 text-left">
                <p className="text-sm text-muted-foreground mb-1">Session Details</p>
                <p className="font-medium text-foreground">{expert.name} - {expert.specialty}</p>
                <p className="text-sm text-muted-foreground">{selectedDate} at {selectedSlot}</p>
                <p className="text-sm text-primary font-medium mt-2">Video consultation link will be sent to your email</p>
              </div>
              <Link to="/">
                <Button variant="hero" className="w-full">Back to Home</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-20">
        {/* Back Button */}
        <Link to="/#experts" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to Experts
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Expert Info */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-elevated mb-6">
              <CardContent className="p-6">
                <div className="flex items-start gap-6">
                  <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-2xl font-bold text-primary-foreground shadow-soft flex-shrink-0">
                    {expert.image}
                  </div>
                  <div className="flex-1">
                    <h1 className="font-display text-2xl font-bold text-foreground mb-1">{expert.name}</h1>
                    <p className="text-muted-foreground mb-2">{expert.title}</p>
                    <Badge variant="secondary" className="bg-wellness-mint text-foreground mb-3">
                      {expert.specialty}
                    </Badge>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-accent text-accent" />
                        <span className="font-medium">{expert.rating}</span>
                        <span className="text-muted-foreground">({expert.reviews} reviews)</span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span>{expert.availability}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="text-muted-foreground mt-4 leading-relaxed">{expert.bio}</p>
                <div className="flex items-center gap-2 mt-4 text-primary">
                  <Video className="w-4 h-4" />
                  <span className="text-sm font-medium">Video consultations available</span>
                </div>
              </CardContent>
            </Card>

            {/* Date Selection */}
            <Card className="border-0 shadow-elevated mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  Select Date
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  {getNextDays().map((day) => (
                    <button
                      key={day.date}
                      onClick={() => setSelectedDate(day.display)}
                      className={`px-4 py-3 rounded-xl border-2 transition-all ${
                        selectedDate === day.display
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <span className="text-sm font-medium">{day.display}</span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Time Slots */}
            <Card className="border-0 shadow-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  Select Time Slot
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                  {expert.slots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setSelectedSlot(slot)}
                      className={`px-4 py-3 rounded-xl border-2 transition-all ${
                        selectedSlot === slot
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <span className="text-sm font-medium">{slot}</span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Summary */}
          <div>
            <Card className="border-0 shadow-elevated sticky top-24">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-primary" />
                  Booking Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Session with {expert.name}</span>
                  <span className="font-medium">${expert.price}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Platform fee</span>
                  <span className="font-medium">$5</span>
                </div>
                <div className="border-t border-border pt-4">
                  <div className="flex justify-between">
                    <span className="font-medium">Total</span>
                    <span className="text-xl font-bold text-primary">${expert.price + 5}</span>
                  </div>
                </div>

                {selectedDate && selectedSlot && (
                  <div className="bg-muted rounded-xl p-3 text-sm">
                    <p className="text-muted-foreground">Selected:</p>
                    <p className="font-medium text-foreground">{selectedDate} at {selectedSlot}</p>
                  </div>
                )}

                <Button 
                  variant="hero" 
                  className="w-full"
                  onClick={handlePayment}
                  disabled={!selectedSlot || !selectedDate || isProcessing}
                >
                  {isProcessing ? "Processing..." : `Pay $${expert.price + 5}`}
                </Button>

                <div className="flex items-center gap-2 justify-center text-xs text-muted-foreground">
                  <Shield className="w-3 h-3" />
                  <span>Secure payment • Cancel anytime</span>
                </div>

                <p className="text-xs text-center text-muted-foreground">
                  This is a demo payment page. No real charges will be made.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BookExpert;