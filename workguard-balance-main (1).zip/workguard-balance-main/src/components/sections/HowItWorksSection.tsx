import { Button } from "@/components/ui/button";
import { ArrowRight, ClipboardList, Cpu, Bell, TrendingUp } from "lucide-react";

const steps = [
  {
    icon: ClipboardList,
    step: "01",
    title: "Log Your Day",
    description: "Spend 30 seconds each day logging your work hours and stress level (Low/Medium/High).",
  },
  {
    icon: Cpu,
    step: "02",
    title: "AI Analysis",
    description: "Our AI analyzes your patterns, comparing against healthy benchmarks and your personal history.",
  },
  {
    icon: Bell,
    step: "03",
    title: "Get Alerts",
    description: "Receive early warnings when we detect overwork patterns or burnout risk indicators.",
  },
  {
    icon: TrendingUp,
    step: "04",
    title: "Improve & Thrive",
    description: "Follow personalized recommendations and track your progress toward better balance.",
  },
];

const HowItWorksSection = () => {
  return (
    <section id="how-it-works" className="py-20 md:py-32 bg-wellness-cream relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />

      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-sm font-semibold text-primary uppercase tracking-wider mb-4">
            How It Works
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Simple Steps to{" "}
            <span className="wellness-gradient-text">Better Balance</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Getting started with WorkGuard AI is easy. Just a few minutes of setup and you're on your way to a healthier work life.
          </p>
        </div>

        {/* Steps */}
        <div className="relative max-w-5xl mx-auto">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-24 left-[10%] right-[10%] h-0.5 bg-gradient-to-r from-primary/20 via-primary to-primary/20" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative text-center">
                {/* Step Number */}
                <div className="relative inline-flex mb-6">
                  <div className="w-20 h-20 rounded-full bg-card shadow-card flex items-center justify-center border-4 border-background">
                    <step.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                    {step.step.slice(-1)}
                  </div>
                </div>

                {/* Content */}
                <h3 className="font-display text-xl font-bold text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <Button variant="hero" size="lg">
            Start Your Journey
            <ArrowRight className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
