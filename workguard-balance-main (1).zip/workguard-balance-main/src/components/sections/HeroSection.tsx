import { Shield, Heart, Brain } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import WorkGuardChat from "@/components/chat/WorkGuardChat";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBg})` }}
      >
        <div className="absolute inset-0 bg-background/60 backdrop-blur-[2px]" />
      </div>

      {/* Floating Elements */}
      <div className="absolute top-1/4 left-10 md:left-20 animate-float opacity-60">
        <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-wellness-teal-light flex items-center justify-center shadow-soft">
          <Shield className="w-8 h-8 md:w-10 md:h-10 text-primary" />
        </div>
      </div>
      <div className="absolute top-1/3 right-10 md:right-32 animate-float opacity-60" style={{ animationDelay: '2s' }}>
        <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-wellness-coral-light flex items-center justify-center shadow-soft">
          <Heart className="w-7 h-7 md:w-8 md:h-8 text-accent" />
        </div>
      </div>
      <div className="absolute bottom-1/4 left-1/4 animate-float opacity-50" style={{ animationDelay: '4s' }}>
        <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-wellness-lavender flex items-center justify-center shadow-soft">
          <Brain className="w-6 h-6 md:w-7 md:h-7 text-primary" />
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text Content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-wellness-teal-light border border-primary/20 mb-6 animate-fade-in">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse-soft" />
              <span className="text-sm font-medium text-primary">AI-Powered Corporate Wellness</span>
            </div>

            {/* Headline */}
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6 animate-slide-up">
              Protect Your{" "}
              <span className="wellness-gradient-text">Well-being</span>
              <br />
              While You Work
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-muted-foreground max-w-xl mb-8 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              WorkGuard AI monitors your work patterns, detects burnout risks early, and provides personalized advice to help you maintain a healthy work-life balance.
            </p>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 text-muted-foreground animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="w-8 h-8 rounded-full bg-wellness-mint border-2 border-background flex items-center justify-center text-xs font-medium text-primary"
                    >
                      {String.fromCharCode(64 + i)}
                    </div>
                  ))}
                </div>
                <span className="text-sm font-medium">1,000+ Happy Employees</span>
              </div>
              <div className="hidden sm:block w-px h-6 bg-border" />
              <div className="flex items-center gap-2">
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <svg key={i} className="w-4 h-4 text-accent fill-current" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  ))}
                </div>
                <span className="text-sm font-medium">4.9/5 Rating</span>
              </div>
            </div>
          </div>

          {/* Right: Chat Widget */}
          <div className="animate-slide-up lg:animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <WorkGuardChat embedded />
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default HeroSection;
