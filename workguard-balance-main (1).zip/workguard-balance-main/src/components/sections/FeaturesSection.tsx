import { Card, CardContent } from "@/components/ui/card";
import { 
  Clock, 
  Brain, 
  AlertTriangle, 
  MessageSquare, 
  BarChart3, 
  Calendar,
  Sparkles,
  Shield
} from "lucide-react";

const features = [
  {
    icon: Clock,
    title: "Daily Work Logging",
    description: "Track your daily work hours and stress levels effortlessly. Our intuitive interface makes it simple to log your day.",
    color: "bg-wellness-teal-light",
    iconColor: "text-primary",
  },
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "Advanced algorithms analyze your work patterns to identify trends and provide personalized insights.",
    color: "bg-wellness-lavender",
    iconColor: "text-primary",
  },
  {
    icon: AlertTriangle,
    title: "Burnout Detection",
    description: "Get early warnings when your work patterns indicate risk of burnout. Prevention is better than cure.",
    color: "bg-wellness-coral-light",
    iconColor: "text-accent",
  },
  {
    icon: MessageSquare,
    title: "Personalized Advice",
    description: "Receive tailored recommendations for breaks, productivity tips, and wellness strategies.",
    color: "bg-wellness-mint",
    iconColor: "text-primary",
  },
  {
    icon: BarChart3,
    title: "Weekly Reports",
    description: "Visual summaries of your work hours, stress trends, and progress toward better balance.",
    color: "bg-wellness-teal-light",
    iconColor: "text-primary",
  },
  {
    icon: Calendar,
    title: "Expert Consultations",
    description: "Book sessions with certified wellness professionals for personalized guidance.",
    color: "bg-wellness-coral-light",
    iconColor: "text-accent",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-20 md:py-32 bg-background relative">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-wellness-teal-light blur-3xl" />
        <div className="absolute bottom-20 right-10 w-64 h-64 rounded-full bg-wellness-coral-light blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-wellness-teal-light border border-primary/20 mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Powerful Features</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Everything You Need for{" "}
            <span className="wellness-gradient-text">Work-Life Balance</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            WorkGuard AI combines intelligent tracking, analysis, and expert guidance to help you thrive at work without sacrificing your well-being.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="group cursor-pointer border-0 bg-card/50 backdrop-blur-sm"
            >
              <CardContent className="p-6 md:p-8">
                <div className={`w-14 h-14 rounded-2xl ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className={`w-7 h-7 ${feature.iconColor}`} />
                </div>
                <h3 className="font-display text-xl font-bold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-3 px-6 py-4 rounded-2xl bg-card shadow-card">
            <Shield className="w-6 h-6 text-primary" />
            <span className="text-foreground font-medium">
              Trusted by 500+ companies worldwide
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
