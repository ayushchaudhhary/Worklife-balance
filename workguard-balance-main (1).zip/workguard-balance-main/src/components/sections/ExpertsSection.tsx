import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Star, Video } from "lucide-react";

const experts = [
  {
    id: "sarah-mitchell",
    name: "Dr. Sarah Mitchell",
    title: "Clinical Psychologist",
    specialty: "Workplace Stress",
    rating: 4.9,
    reviews: 127,
    availability: "Mon-Fri, 9AM-5PM",
    price: "$75/session",
    image: "SM",
  },
  {
    id: "michael-chen",
    name: "Michael Chen",
    title: "Executive Coach",
    specialty: "Work-Life Balance",
    rating: 4.8,
    reviews: 89,
    availability: "Tue-Sat, 10AM-6PM",
    price: "$90/session",
    image: "MC",
  },
  {
    id: "emily-rodriguez",
    name: "Dr. Emily Rodriguez",
    title: "Wellness Consultant",
    specialty: "Burnout Prevention",
    rating: 5.0,
    reviews: 156,
    availability: "Mon-Thu, 8AM-4PM",
    price: "$85/session",
    image: "ER",
  },
];

const ExpertsSection = () => {
  return (
    <section id="experts" className="py-20 md:py-32 bg-background relative">
      {/* Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-wellness-lavender blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-wellness-mint blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge variant="outline" className="mb-4 px-4 py-1 text-primary border-primary/30 bg-wellness-teal-light">
            Premium Support
          </Badge>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Connect with{" "}
            <span className="wellness-gradient-text">Certified Experts</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Book one-on-one sessions with our verified wellness professionals for personalized guidance and support.
          </p>
        </div>

        {/* Experts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto">
          {experts.map((expert, index) => (
            <Card 
              key={index}
              className="group overflow-hidden border-0 bg-card/80 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                {/* Profile Header */}
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xl font-bold text-primary-foreground shadow-soft">
                    {expert.image}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-display text-lg font-bold text-foreground">
                      {expert.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{expert.title}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-4 h-4 fill-accent text-accent" />
                      <span className="text-sm font-medium text-foreground">{expert.rating}</span>
                      <span className="text-sm text-muted-foreground">({expert.reviews} reviews)</span>
                    </div>
                  </div>
                </div>

                {/* Specialty */}
                <Badge variant="secondary" className="mb-4 bg-wellness-mint text-foreground">
                  {expert.specialty}
                </Badge>

                {/* Details */}
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4 text-primary" />
                    <span>{expert.availability}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Video className="w-4 h-4 text-primary" />
                    <span>Video consultations available</span>
                  </div>
                </div>

                {/* Price & CTA */}
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <span className="text-lg font-bold text-foreground">{expert.price}</span>
                  <Link to={`/book/${expert.id}`}>
                    <Button variant="coral" size="sm">
                      <Calendar className="w-4 h-4" />
                      Book Slot
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* View All */}
        <div className="text-center mt-12">
          <Button variant="hero-outline" size="lg">
            View All Experts
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ExpertsSection;
