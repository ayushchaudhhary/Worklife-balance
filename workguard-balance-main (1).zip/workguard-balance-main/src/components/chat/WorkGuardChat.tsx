import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Send, 
  Bot, 
  User, 
  Loader2, 
  RotateCcw,
  Minimize2,
  Maximize2,
  MessageCircle,
  X,
  AlertCircle
} from "lucide-react";
import { useWorkGuardChat } from "@/hooks/useWorkGuardChat";

interface WorkGuardChatProps {
  embedded?: boolean;
}

const WorkGuardChat = ({ embedded = false }: WorkGuardChatProps) => {
  const { messages, isLoading, error, sendMessage, clearChat } = useWorkGuardChat();
  const [inputValue, setInputValue] = useState("");
  const [isOpen, setIsOpen] = useState(embedded);
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;
    sendMessage(inputValue);
    setInputValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  // Floating chat button (only shown when not embedded and chat is closed)
  if (!embedded && !isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary shadow-elevated hover:shadow-glow flex items-center justify-center transition-all duration-300 hover:scale-105 group"
      >
        <MessageCircle className="w-6 h-6 text-primary-foreground" />
        <span className="absolute -top-2 -right-1 w-4 h-4 rounded-full bg-accent flex items-center justify-center">
          <span className="text-[10px] text-accent-foreground font-bold">1</span>
        </span>
      </button>
    );
  }

  const chatContent = (
    <>
      {/* Chat Header */}
      <div className="p-4 border-b border-border flex items-center justify-between bg-card">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shadow-soft">
            <Bot className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h4 className="font-display font-semibold text-foreground">WorkGuard AI</h4>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-stress-low animate-pulse" />
              <span className="text-xs text-muted-foreground">Online • Ready to help</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={clearChat}
            className="h-8 w-8"
            title="Clear chat"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
          {!embedded && (
            <>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsMinimized(!isMinimized)}
                className="h-8 w-8"
              >
                {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsOpen(false)}
                className="h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 p-4 space-y-4 overflow-y-auto min-h-[300px] max-h-[400px] bg-muted/30">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex gap-3 animate-fade-in ${message.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === "user" 
                    ? "bg-wellness-lavender" 
                    : "bg-primary"
                }`}>
                  {message.role === "user" ? (
                    <User className="w-4 h-4 text-primary" />
                  ) : (
                    <Bot className="w-4 h-4 text-primary-foreground" />
                  )}
                </div>
                <div className={`max-w-[80%] p-3 rounded-2xl ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground rounded-tr-md"
                    : "bg-card text-foreground rounded-tl-md shadow-soft"
                }`}>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex gap-3 animate-fade-in">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                  <Bot className="w-4 h-4 text-primary-foreground" />
                </div>
                <div className="bg-card text-foreground p-3 rounded-2xl rounded-tl-md shadow-soft">
                  <Loader2 className="w-4 h-4 animate-spin text-primary" />
                </div>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 p-3 bg-destructive/10 rounded-lg text-destructive text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="p-4 border-t border-border bg-card">
            <div className="flex items-center gap-3">
              <input
                type="text"
                placeholder="Share how your day went..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isLoading}
                className="flex-1 px-4 py-3 rounded-xl bg-muted border-0 focus:outline-none focus:ring-2 focus:ring-primary/20 text-foreground placeholder:text-muted-foreground disabled:opacity-50"
              />
              <Button 
                type="submit" 
                variant="hero" 
                size="icon" 
                className="w-12 h-12 rounded-xl"
                disabled={isLoading || !inputValue.trim()}
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              WorkGuard AI provides general wellness advice, not medical guidance.
            </p>
          </form>
        </>
      )}
    </>
  );

  if (embedded) {
    return (
      <Card className="border-0 shadow-elevated bg-card overflow-hidden flex flex-col">
        <CardContent className="p-0 flex flex-col h-full">
          {chatContent}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-[400px] max-w-[calc(100vw-48px)] shadow-elevated rounded-2xl overflow-hidden border border-border bg-card flex flex-col animate-scale-in">
      {chatContent}
    </div>
  );
};

export default WorkGuardChat;
